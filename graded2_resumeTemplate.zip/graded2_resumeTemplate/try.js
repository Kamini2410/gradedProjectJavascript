$('#search').keyup(function() {
    var searchField = $('#search').val();
    $.getJSON(Data (1).json, function(data) {
    console.log(data);
        var output = '<ul class="searchresults">';
        $.each(data.basics.appliedFor, function(k, obj) {
            if(obj[searchField]) {
                output += '<li>' + obj[searchField] + '</li>';
            }
        });
        output += '</ul>';
        $('#result').html(output);
    });  
});




